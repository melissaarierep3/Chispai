// Azure Function: Chispai Reminder & Notification Orchestrator
// Triggered by timer (every 30 minutes) or queue message
// Handles: IMS Breaks, predictive reminders, gamification, contextual nudges

const { CosmosClient } = require("@azure/cosmos");
const sql = require("mssql");
const axios = require("axios");

module.exports = async function (context, timerOrQueueItem) {
  const startTime = new Date();
  context.log(`Chispai Reminder Job Started at ${startTime}`);

  try {
    // Initialize clients
    const cosmosClient = new CosmosClient({
      endpoint: process.env.COSMOS_ENDPOINT,
      key: process.env.COSMOS_KEY,
    });

    const sqlPool = new sql.ConnectionPool(process.env.SQL_CONNECTION_STRING);
    await sqlPool.connect();

    // Fetch all active reminder settings
    const reminderQuery = `
      SELECT 
        rs.reminderId,
        rs.userId,
        rs.habitId,
        rs.frequency,
        rs.startTime,
        rs.endTime,
        rs.intervalMinutes,
        rs.notificationType,
        h.name AS habitName,
        u.preferredLanguage
      FROM ReminderSettings rs
      JOIN Habits h ON rs.habitId = h.habitId
      JOIN Users u ON rs.userId = u.userId
      WHERE rs.enabled = 1
    `;

    const result = await sqlPool.request().query(reminderQuery);
    const reminders = result.recordset;

    context.log(`Found ${reminders.length} active reminders`);

    // Process each reminder
    for (const reminder of reminders) {
      try {
        // Check time window
        const now = new Date();
        const currentTime = now.getHours() * 60 + now.getMinutes();

        const [startHour, startMin] = reminder.startTime
          .split(":")
          .map((x) => parseInt(x));
        const [endHour, endMin] = reminder.endTime
          .split(":")
          .map((x) => parseInt(x));

        const startTimeMin = startHour * 60 + startMin;
        const endTimeMin = endHour * 60 + endMin;

        // Skip if outside notification window
        if (currentTime < startTimeMin || currentTime > endTimeMin) {
          continue;
        }

        // Route to appropriate notification layer
        switch (reminder.notificationType) {
          case "ims_break":
            await sendIMSBreak(reminder, context);
            break;
          case "predictive":
            await sendPredictiveReminder(reminder, context, sqlPool);
            break;
          case "gamification":
            await sendGamificationReminder(reminder, context, sqlPool);
            break;
          case "contextual":
            await sendContextualReminder(reminder, context, sqlPool);
            break;
        }

        // Log reminder sent
        await logReminderEvent(reminder.userId, reminder.habitId, "sent", sqlPool);
      } catch (reminderError) {
        context.log(`Error processing reminder: ${reminderError.message}`);
      }
    }

    sqlPool.close();
    context.log(
      `Chispai Reminder Job completed in ${new Date() - startTime}ms`
    );

    return {
      status: "success",
      remindersProcessed: reminders.length,
      duration: new Date() - startTime,
    };
  } catch (error) {
    context.log.error(`Fatal error in reminder job: ${error.message}`);
    throw error;
  }
};

// ============================================
// LAYER 1: IMS BREAK (Instant Mindful Silence)
// ============================================
async function sendIMSBreak(reminder, context) {
  const message = buildIMSMessage(reminder.habitName);

  const notification = {
    userId: reminder.userId,
    type: "ims_break",
    title: "🧘 Instant Mindful Silence",
    message: message,
    sound: "tibetan_bowl.mp3",
    soundDuration: 3000, // 3 seconds
    actions: [{ label: "Just logged!", action: "log_habit" }],
    timestamp: new Date(),
  };

  await sendNotification(notification, context);
}

function buildIMSMessage(habitName) {
  const messages = [
    `🌊 One glass centers you. ${habitName}?`,
    `💪 Your body's asking for ${habitName}. Listen to it.`,
    `🧘 Pause. Breathe. One ${habitName} moment.`,
    `✨ ${habitName} = inner peace right now.`,
  ];

  return messages[Math.floor(Math.random() * messages.length)];
}

// ============================================
// LAYER 2: PREDICTIVE TIMING
// ============================================
async function sendPredictiveReminder(reminder, context, sqlPool) {
  try {
    // Query calendar for upcoming meetings
    const calendarQuery = `
      SELECT TOP 1 
        eventName,
        startTime
      FROM CalendarEvents
      WHERE userId = @userId
        AND startTime > GETUTCDATE()
        AND startTime < DATEADD(HOUR, 2, GETUTCDATE())
      ORDER BY startTime ASC
    `;

    const request = sqlPool.request();
    request.input("userId", reminder.userId);
    const calendarResult = await request.query(calendarQuery);

    let predictiveMessage = "";

    if (calendarResult.recordset.length > 0) {
      // Pre-meeting reminder
      const event = calendarResult.recordset[0];
      predictiveMessage = `🏃 Your "${event.eventName}" is in 15 min.\n${reminder.habitName} + 1-min breath first?`;
    } else {
      const hour = new Date().getHours();

      // Time-based suggestions
      if (hour === 12 || hour === 13) {
        predictiveMessage = `🍽️ Post-lunch hydration boost time. One ${reminder.habitName}?`;
      } else if (hour === 15) {
        predictiveMessage = `😴 Afternoon slump @ 3 PM.\n${reminder.habitName}, then take a 5-min walk?`;
      } else {
        predictiveMessage = `💚 Your body's asking for ${reminder.habitName}. Listen.`;
      }
    }

    const notification = {
      userId: reminder.userId,
      type: "predictive",
      title: "⏰ Smart Timing",
      message: predictiveMessage,
      actions: [
        { label: "Done", action: "log_habit" },
        { label: "Later", action: "snooze" },
      ],
      timestamp: new Date(),
    };

    await sendNotification(notification, context);
  } catch (error) {
    context.log(`Predictive reminder error: ${error.message}`);
  }
}

// ============================================
// LAYER 3: GAMIFICATION
// ============================================
async function sendGamificationReminder(reminder, context, sqlPool) {
  try {
    const statsQuery = `
      SELECT 
        COUNT(*) as completionsToday,
        h.streakDays
      FROM HabitLogs hl
      JOIN Habits h ON hl.habitId = h.habitId
      WHERE hl.userId = @userId
        AND CAST(hl.date AS DATE) = CAST(GETUTCDATE() AS DATE)
        AND h.habitId = @habitId
      GROUP BY h.streakDays
    `;

    const request = sqlPool.request();
    request.input("userId", reminder.userId);
    request.input("habitId", reminder.habitId);
    const statsResult = await request.query(statsQuery);

    const stats = statsResult.recordset[0] || { completionsToday: 0, streakDays: 0 };

    let gamificationMessage = "";

    if (stats.completionsToday === 0) {
      gamificationMessage = `🎯 You haven't logged ${reminder.habitName} yet today.\nGain streak & points now!`;
    } else if (stats.completionsToday === 4) {
      gamificationMessage = `🏆 4 completions today! One more for a badge unlock!`;
    } else if (stats.streakDays === 6) {
      gamificationMessage = `🔥 One more day for a 7-day milestone!\nKeep the spark alive.`;
    }

    const notification = {
      userId: reminder.userId,
      type: "gamification",
      title: "🎮 Gamification",
      message: gamificationMessage,
      actions: [{ label: "Log Now", action: "log_habit" }],
      timestamp: new Date(),
    };

    await sendNotification(notification, context);
  } catch (error) {
    context.log(`Gamification reminder error: ${error.message}`);
  }
}

// ============================================
// LAYER 4: CONTEXTUAL NUDGE
// ============================================
async function sendContextualReminder(reminder, context, sqlPool) {
  try {
    const contextQuery = `
      SELECT TOP 1 
        hl.emotionalContext
      FROM HabitLogs hl
      WHERE hl.userId = @userId
        AND hl.habitId = @habitId
        AND CAST(hl.date AS DATE) = CAST(GETUTCDATE() AS DATE)
    `;

    const request = sqlPool.request();
    request.input("userId", reminder.userId);
    request.input("habitId", reminder.habitId);
    const contextResult = await request.query(contextQuery);

    // If not logged yet by afternoon, send contextual nudge
    if (contextResult.recordset.length === 0) {
      const now = new Date();

      if (now.getHours() >= 14) {
        // 2 PM or later
        const contextualMessage = `You've been heads-down for hours.\nYour body's asking for ${reminder.habitName}.\nOne moment of care? 💚`;

        const notification = {
          userId: reminder.userId,
          type: "contextual",
          title: "💭 Contextual Nudge",
          message: contextualMessage,
          actions: [
            { label: "Listen", action: "log_habit" },
            { label: "Later", action: "snooze" },
          ],
          timestamp: new Date(),
        };

        await sendNotification(notification, context);
      }
    }
  } catch (error) {
    context.log(`Contextual reminder error: ${error.message}`);
  }
}

// ============================================
// SEND NOTIFICATION (via Azure Notification Hubs or direct API)
// ============================================
async function sendNotification(notification, context) {
  try {
    // Option 1: Send via Notification Hub REST API
    const notificationHubUrl = `${process.env.NOTIFICATION_HUB_ENDPOINT}/messages`;

    await axios.post(notificationHubUrl, notification, {
      headers: {
        Authorization: `SharedAccessSignature ${process.env.NOTIFICATION_HUB_KEY}`,
        "Content-Type": "application/json",
      },
    });

    context.log(
      `Notification sent to ${notification.userId}: ${notification.title}`
    );
  } catch (error) {
    context.log(`Error sending notification: ${error.message}`);

    // Fallback: Log to queue for retry
    context.bindings.notificationQueue = notification;
  }
}

// ============================================
// LOG REMINDER EVENT
// ============================================
async function logReminderEvent(userId, habitId, status, sqlPool) {
  const logQuery = `
    INSERT INTO ReminderLog (userId, habitId, status, timestamp)
    VALUES (@userId, @habitId, @status, GETUTCDATE())
  `;

  const request = sqlPool.request();
  request.input("userId", userId);
  request.input("habitId", habitId);
  request.input("status", status);

  await request.query(logQuery);
}

// ============================================
// TRANSLATIONS (English & Spanish)
// ============================================
function getLocalizedMessage(key, language = "en") {
  const messages = {
    en: {
      ims_hydrate: "🌊 One glass centers you.",
      ims_gym: "💪 Your body's asking for movement.",
      ims_read: "📚 Your mind needs escape.",
    },
    es: {
      ims_hydrate: "🌊 Un vaso te centra.",
      ims_gym: "💪 Tu cuerpo pide movimiento.",
      ims_read: "📚 Tu mente necesita escapar.",
    },
  };

  return messages[language]?.[key] || messages["en"][key];
}
