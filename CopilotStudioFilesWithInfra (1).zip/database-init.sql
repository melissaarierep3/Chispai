-- Chispai Database Initialization Script
-- Run against Azure SQL Server
-- Creates all tables for user profiles, habits, logs, and zen gardens

USE [chispai-dev-db];
GO

-- ============================================
-- USERS TABLE
-- ============================================
CREATE TABLE [dbo].[Users] (
  [userId] UNIQUEIDENTIFIER PRIMARY KEY DEFAULT NEWID(),
  [name] NVARCHAR(255) NOT NULL,
  [email] NVARCHAR(255) UNIQUE,
  [preferredLanguage] VARCHAR(2) DEFAULT 'en', -- en | es
  [timeZone] NVARCHAR(50) DEFAULT 'America/Guatemala',
  [stressLevel] VARCHAR(20) DEFAULT 'Medium', -- Low | Medium | High
  [points] INT DEFAULT 0,
  [streaksActive] INT DEFAULT 0,
  [lastSundayPlan] DATETIME2,
  [createdAt] DATETIME2 DEFAULT GETUTCDATE(),
  [updatedAt] DATETIME2 DEFAULT GETUTCDATE()
);

CREATE INDEX [IX_Users_Email] ON [dbo].[Users]([email]);
GO

-- ============================================
-- HABITS TABLE
-- ============================================
CREATE TABLE [dbo].[Habits] (
  [habitId] UNIQUEIDENTIFIER PRIMARY KEY DEFAULT NEWID(),
  [userId] UNIQUEIDENTIFIER NOT NULL FOREIGN KEY REFERENCES [dbo].[Users]([userId]),
  [name] NVARCHAR(255) NOT NULL, -- "Drink 8 glasses of water"
  [category] VARCHAR(50) NOT NULL, -- Hydration | Vitamins | Gym | Reading | Sleep | Mindfulness
  [targetFrequency] VARCHAR(20) DEFAULT 'daily', -- daily | weekly
  [streakDays] INT DEFAULT 0,
  [streakPaused] BIT DEFAULT 0,
  [lastPausedReason] NVARCHAR(MAX),
  [currentWeek] NVARCHAR(MAX), -- JSON array: [bool, bool, ...] M-Sun
  [totalCompletions] INT DEFAULT 0,
  [icon] NVARCHAR(10), -- emoji
  [createdAt] DATETIME2 DEFAULT GETUTCDATE(),
  [updatedAt] DATETIME2 DEFAULT GETUTCDATE()
);

CREATE INDEX [IX_Habits_UserId] ON [dbo].[Habits]([userId]);
CREATE INDEX [IX_Habits_Category] ON [dbo].[Habits]([category]);
GO

-- ============================================
-- HABIT LOGS TABLE
-- ============================================
CREATE TABLE [dbo].[HabitLogs] (
  [logId] UNIQUEIDENTIFIER PRIMARY KEY DEFAULT NEWID(),
  [userId] UNIQUEIDENTIFIER NOT NULL FOREIGN KEY REFERENCES [dbo].[Users]([userId]),
  [habitId] UNIQUEIDENTIFIER NOT NULL FOREIGN KEY REFERENCES [dbo].[Habits]([habitId]),
  [date] DATE NOT NULL,
  [completed] BIT NOT NULL DEFAULT 0,
  [emotionalContext] VARCHAR(50), -- Energized | Good | Neutral | Tough | Burnt
  [manualEntry] BIT DEFAULT 0,
  [notes] NVARCHAR(MAX),
  [createdAt] DATETIME2 DEFAULT GETUTCDATE()
);

CREATE INDEX [IX_HabitLogs_UserId_Date] ON [dbo].[HabitLogs]([userId], [date]);
CREATE INDEX [IX_HabitLogs_HabitId] ON [dbo].[HabitLogs]([habitId]);
GO

-- ============================================
-- ZEN GARDEN TABLE
-- ============================================
CREATE TABLE [dbo].[ZenGardens] (
  [userId] UNIQUEIDENTIFIER PRIMARY KEY FOREIGN KEY REFERENCES [dbo].[Users]([userId]),
  [level] INT DEFAULT 1,
  [points] INT DEFAULT 0,
  [zenTemple] BIT DEFAULT 0,
  [sakuraTrees] INT DEFAULT 0,
  [virtualPet] NVARCHAR(255), -- e.g., "Zen the Koi"
  [decorations] NVARCHAR(MAX), -- JSON array: ["Stone Lantern", "Bridge", ...]
  [updatedAt] DATETIME2 DEFAULT GETUTCDATE()
);
GO

-- ============================================
-- SUNDAY PLANS TABLE
-- ============================================
CREATE TABLE [dbo].[SundayPlans] (
  [planId] UNIQUEIDENTIFIER PRIMARY KEY DEFAULT NEWID(),
  [userId] UNIQUEIDENTIFIER NOT NULL FOREIGN KEY REFERENCES [dbo].[Users]([userId]),
  [weekStartDate] DATE NOT NULL,
  [rawVoiceNotes] NVARCHAR(MAX),
  [extractedPriorities] NVARCHAR(MAX), -- JSON
  [suggestedSchedule] NVARCHAR(MAX),
  [habitsForWeek] NVARCHAR(MAX), -- JSON array of habitIds
  [weeklyIntention] NVARCHAR(500),
  [createdAt] DATETIME2 DEFAULT GETUTCDATE()
);

CREATE INDEX [IX_SundayPlans_UserId_WeekStart] ON [dbo].[SundayPlans]([userId], [weekStartDate]);
GO

-- ============================================
-- MENTAL HEALTH LOGS TABLE
-- ============================================
CREATE TABLE [dbo].[MentalHealthLogs] (
  [logId] UNIQUEIDENTIFIER PRIMARY KEY DEFAULT NEWID(),
  [userId] UNIQUEIDENTIFIER NOT NULL FOREIGN KEY REFERENCES [dbo].[Users]([userId]),
  [date] DATETIME2 NOT NULL DEFAULT GETUTCDATE(),
  [emotionalState] NVARCHAR(255),
  [crisisLevel] VARCHAR(20), -- low | medium | high | critical
  [actionTaken] NVARCHAR(MAX),
  [followUpScheduled] BIT DEFAULT 0,
  [followUpDate] DATETIME2
);

CREATE INDEX [IX_MentalHealthLogs_UserId_Date] ON [dbo].[MentalHealthLogs]([userId], [date]);
GO

-- ============================================
-- REMINDER SETTINGS TABLE
-- ============================================
CREATE TABLE [dbo].[ReminderSettings] (
  [reminderId] UNIQUEIDENTIFIER PRIMARY KEY DEFAULT NEWID(),
  [userId] UNIQUEIDENTIFIER NOT NULL FOREIGN KEY REFERENCES [dbo].[Users]([userId]),
  [habitId] UNIQUEIDENTIFIER NOT NULL FOREIGN KEY REFERENCES [dbo].[Habits]([habitId]),
  [frequency] VARCHAR(50) NOT NULL, -- daily | weekly | custom
  [startTime] TIME,
  [endTime] TIME,
  [intervalMinutes] INT, -- for IMS Breaks: 120 (every 2 hours)
  [notificationType] VARCHAR(50), -- ims_break | predictive | gamification | contextual
  [enabled] BIT DEFAULT 1,
  [createdAt] DATETIME2 DEFAULT GETUTCDATE()
);

CREATE INDEX [IX_ReminderSettings_UserId] ON [dbo].[ReminderSettings]([userId]);
GO

-- ============================================
-- STORED PROCEDURES
-- ============================================

-- Get user with all related data
CREATE PROCEDURE sp_GetUserWithHabits
  @userId UNIQUEIDENTIFIER
AS
BEGIN
  SELECT u.* FROM Users u WHERE u.userId = @userId;
  
  SELECT h.* FROM Habits h 
  WHERE h.userId = @userId 
  ORDER BY h.createdAt DESC;
  
  SELECT z.* FROM ZenGardens z 
  WHERE z.userId = @userId;
END;
GO

-- Log habit completion
CREATE PROCEDURE sp_LogHabitCompletion
  @userId UNIQUEIDENTIFIER,
  @habitId UNIQUEIDENTIFIER,
  @emotionalContext VARCHAR(50) = NULL
AS
BEGIN
  DECLARE @today DATE = CAST(GETUTCDATE() AS DATE);
  
  -- Check if already logged today
  IF EXISTS (
    SELECT 1 FROM HabitLogs 
    WHERE habitId = @habitId AND userId = @userId AND date = @today
  )
  BEGIN
    RAISERROR('Habit already logged for today', 16, 1);
    RETURN;
  END
  
  -- Insert habit log
  INSERT INTO HabitLogs (userId, habitId, date, completed, emotionalContext)
  VALUES (@userId, @habitId, @today, 1, @emotionalContext);
  
  -- Update habit streak
  DECLARE @streakDays INT = (SELECT streakDays FROM Habits WHERE habitId = @habitId);
  UPDATE Habits 
  SET streakDays = @streakDays + 1, 
      updatedAt = GETUTCDATE()
  WHERE habitId = @habitId;
  
  -- Award points
  UPDATE Users 
  SET points = points + 25, 
      updatedAt = GETUTCDATE()
  WHERE userId = @userId;
  
  -- Update Zen Garden
  UPDATE ZenGardens 
  SET points = points + 25, 
      updatedAt = GETUTCDATE()
  WHERE userId = @userId;
  
  SELECT 'Habit logged successfully' AS message;
END;
GO

-- Reset habit streak (compassionate)
CREATE PROCEDURE sp_ResetHabitStreak
  @habitId UNIQUEIDENTIFIER,
  @reason NVARCHAR(MAX) = NULL
AS
BEGIN
  UPDATE Habits 
  SET streakDays = 0, 
      streakPaused = 1,
      lastPausedReason = @reason,
      updatedAt = GETUTCDATE()
  WHERE habitId = @habitId;
  
  SELECT 'Habit streak reset with compassion' AS message;
END;
GO

-- Get weekly habit summary
CREATE PROCEDURE sp_GetWeeklySummary
  @userId UNIQUEIDENTIFIER
AS
BEGIN
  DECLARE @startOfWeek DATE = DATEADD(DAY, -DATEDIFF(DAY, 0, GETUTCDATE()) % 7, CAST(GETUTCDATE() AS DATE));
  
  SELECT 
    h.habitId,
    h.name,
    h.category,
    h.streakDays,
    COUNT(CASE WHEN hl.completed = 1 THEN 1 END) AS completionsThisWeek,
    h.streakDays AS currentStreak
  FROM Habits h
  LEFT JOIN HabitLogs hl ON h.habitId = hl.habitId 
    AND hl.date >= @startOfWeek 
    AND hl.userId = @userId
  WHERE h.userId = @userId
  GROUP BY h.habitId, h.name, h.category, h.streakDays;
END;
GO

-- Get points and level
CREATE PROCEDURE sp_GetUserProgress
  @userId UNIQUEIDENTIFIER
AS
BEGIN
  SELECT 
    u.points,
    z.level,
    z.sakuraTrees,
    z.decorations,
    z.virtualPet,
    CASE 
      WHEN z.points < 501 THEN 'Level 1: Starter'
      WHEN z.points < 1501 THEN 'Level 2: Caretaker'
      WHEN z.points < 3501 THEN 'Level 3: Cultivator'
      ELSE 'Level 4: Master'
    END AS levelName
  FROM Users u
  LEFT JOIN ZenGardens z ON u.userId = z.userId
  WHERE u.userId = @userId;
END;
GO

-- ============================================
-- SEED DATA (Optional for testing)
-- ============================================

-- Uncomment to seed test data:
/*
INSERT INTO Users (userId, name, email, preferredLanguage, points)
VALUES (NEWID(), 'Test User', 'test@chispai.com', 'en', 100);
*/

PRINT 'Chispai database initialized successfully!';
GO
