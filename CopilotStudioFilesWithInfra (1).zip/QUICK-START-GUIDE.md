# Chispai Copilot Studio — Quick Start Implementation Guide

## Phase 1: Agent Setup (Day 1-2)

### 1. Create Agent in Azure Copilot Studio
```
Portal: https://copilotstudio.microsoft.com
Step 1: New Agent → Choose "Conversational"
Step 2: Name: Chispai
Step 3: Persona: "I am Chispai, an AI wellness companion..."
Step 4: Language: English & Spanish
```

### 2. Configure System Prompt
Copy this into Agent Settings → System Prompt:

```
You are Chispai, an AI wellness companion built with warmth and wisdom. 
Your mission is to help users manage anxiety, build sustainable daily habits, 
and stay motivated through balance and self-compassion.

CORE PRINCIPLES:
1. Awaken, don't judge — gently awaken their inner spark
2. Embrace imperfection (Wabi-Sabi) — no shame, just adjustment
3. Real-world actions — walks, kind words, gym sessions
4. Cortisol-aware — doomscrolling is the enemy
5. Zen Garden philosophy — consistency grows the sanctuary

TONE: Warm, empathetic, occasionally witty. Like a wise friend.

INSTRUCTIONS:
- Always validate emotional state before fixing
- Suggest real-world actions (not abstract meditation)
- When someone misses a habit, show compassion + reset
- If crisis detected, recommend human support
- Never lecture or shame
- Use metaphors: garden, spark, sanctuary, harmony
```

---

## Phase 2: Core Topics (Day 3-5)

### Topic 1: Sunday Planning

**Setup in Copilot Studio:**
```
Topics → New Topic
Name: Sunday Planning
Trigger Phrases:
  - organize my week
  - sunday planning
  - help me prioritize
  - i'm overwhelmed with my week
```

**Conversation Flow:**
```
System Message: "Good Sunday. Ready to organize your week? Send me a voice note or type about what's on your mind."

User Input: [Voice note or text]

Condition 1: If voice input
  → Call Microsoft Foundry API: transcribe_audio()
  → Extract entities: priorities, meetings, deadlines, health_goals

Condition 2: Cross-reference calendar
  → Call Microsoft Work IQ API: get_calendar_load()
  → Detect high-stress windows
  → Suggest IMS Breaks (5-min mindful silences)

Action: Generate response
Template:
"Got it. I hear the [emotion]. Let's make sense of it.

📊 YOUR WEEK ORGANIZED:
[Day-by-day breakdown with priority levels]

🎯 HABITS THIS WEEK:
[Recommended 3-5 habits with frequency]

✨ YOUR MANTRA:
[User-specific motivational mantra]

Reminders set. I'll send gentle nudges. You're organized now. 💚"

Save to Database:
  → SundayPlan entity with userId, weekStartDate, extractedPriorities, habitsForWeek
```

### Topic 2: Log Habit

**Trigger Phrases:**
```
- [habit name] done
- drank water
- went to gym
- took vitamins
- finished reading
- logged [habit]
```

**Flow:**
```
Step 1: Extract habit + emotional context
Step 2: Retrieve current streak
Step 3: Award points + update streak
Step 4: Respond with celebration

Response Template:
"🔥 Amazing! [Habit] logged.

STREAK: 🔥🔥🔥🔥 (4 days)
REWARDS: +25 Zen Points
MILESTONE: 2 days until 'Hydration Hero' badge

What was today's vibe?
→ Energized | Good | Neutral | Tough | Burnt out"

Database:
  → HabitLog: completed = true, emotionalContext = [user choice]
  → Habit: streakDays++, currentWeek[today] = true
  → User: points += 25, zeniGarden update
```

### Topic 3: Missed Habit (Compassionate)

**Trigger Phrases:**
```
- i skipped [habit]
- i didn't [habit]
- i'm unmotivated
- i feel like i'm failing
- the weekend threw me off
```

**Flow:**
```
Step 1: Detect shame/guilt via sentiment analysis
Step 2: Assess context (stress level this week, other successes)
Step 3: Respond with compassion + validation
Step 4: Suggest micro-action for tomorrow
Step 5: Reset streak WITHOUT shame

Response Template:
"Stop. You're not failing. You're [human/overwhelmed/needing rest].

I see you:
✓ Water: 6/7 days (incredible)
✓ Mom call: Happened (relationships strong)
✓ Reading: Done (mental escape intact)

The [habit] is ONE thing. You succeeded at 4 others.

RESET FOR TOMORROW:
→ 15-min walk instead of 30-min gym
→ No equipment, no pressure
→ Just movement

Your [X]-day streak pauses, but progress stays locked.
You're not behind. You're exactly where a human should be.
Let's build from here. 💚"

Database:
  → Habit: streakDays = 0, streakPaused = true
  → HabitLog: completed = false, reasonMissed = [context]
```

---

## Phase 3: Data Model Setup (Day 6)

### Database Tables (Azure SQL or Cosmos DB)

**Table: Users**
```sql
CREATE TABLE Users (
  userId UUID PRIMARY KEY,
  name VARCHAR(255),
  preferredLanguage VARCHAR(2), -- en | es
  timeZone VARCHAR(50),
  stressLevel VARCHAR(20), -- Low | Medium | High
  points INT DEFAULT 0,
  streaksActive INT DEFAULT 0,
  lastSundayPlan DATETIME,
  createdAt DATETIME
);
```

**Table: Habits**
```sql
CREATE TABLE Habits (
  habitId UUID PRIMARY KEY,
  userId UUID FOREIGN KEY,
  name VARCHAR(255), -- "Drink 8 glasses of water"
  category VARCHAR(50), -- Hydration | Vitamins | Gym | Reading
  streakDays INT DEFAULT 0,
  currentWeek JSON, -- [Mon, Tue, Wed, Thu, Fri, Sat, Sun] = [bool, bool...]
  totalCompletions INT DEFAULT 0,
  createdAt DATETIME
);
```

**Table: HabitLogs**
```sql
CREATE TABLE HabitLogs (
  logId UUID PRIMARY KEY,
  userId UUID FOREIGN KEY,
  habitId UUID FOREIGN KEY,
  date DATE,
  completed BOOLEAN,
  emotionalContext VARCHAR(255), -- Energized | Good | Neutral | Tough | Burnt
  manualEntry BOOLEAN DEFAULT false,
  createdAt DATETIME
);
```

**Table: ZenGarden**
```sql
CREATE TABLE ZenGarden (
  userId UUID PRIMARY KEY FOREIGN KEY,
  level INT DEFAULT 1,
  points INT DEFAULT 0,
  zenTemple BOOLEAN DEFAULT false,
  sakuraTrees INT DEFAULT 0,
  virtualPet VARCHAR(255) NULL, -- e.g., "Zen the Koi"
  decorations JSON, -- ["Stone Lantern", "Bridge", "Fountain"]
  updatedAt DATETIME
);
```

**Table: SundayPlans**
```sql
CREATE TABLE SundayPlans (
  planId UUID PRIMARY KEY,
  userId UUID FOREIGN KEY,
  weekStartDate DATE,
  rawVoiceNotes TEXT,
  extractedPriorities JSON,
  suggestedSchedule TEXT,
  habitsForWeek JSON, -- array of habitIds
  weeklyIntention VARCHAR(500),
  createdAt DATETIME
);
```

---

## Phase 4: Rewards & Gamification (Day 7)

### Points System (Hardcode in Agent Logic)

```javascript
const POINTS_AWARD = {
  dailyHabitCompletion: 10,        // Each habit done = +10
  streak_7_days: 50,               // 7-day milestone = +50 bonus
  streak_14_days: 100,
  streak_30_days: 250,
  perfectWeek: 100,                // All habits 7 days
  emotionalCheckin: 5,             // Logging mood
  cortisol_detox: 25,              // Completed real-world challenge
  mentalHealthEngagement: 15       // Used support feature
};

const ZEN_GARDEN_LEVELS = {
  level1: { threshold: 0,    unlock: "Zen Garden" },
  level2: { threshold: 501,  unlock: "Zen Temple" },
  level3: { threshold: 1501, unlock: "Sakura Trees" },
  level4: { threshold: 3501, unlock: "Virtual Pet" }
};

const DECORATIONS = {
  "7_day_streak": "🏮 Stone Lantern",
  "14_day_streak": "🌉 Meditation Bridge",
  "21_day_streak": "⛲ Water Fountain",
  "30_day_streak": "🌸 Cherry Tree",
  "3_habits_30_days": "🏛️ Golden Buddha"
};
```

### Zen Garden ASCII Visualization

```
When user asks "Show my garden":

Display:
                 🌸🌸
            🌸       🌸
         🌸   🧘   🌸
          \  /
       ▔▔▔▔▔▔▔▔▔▔
      🏯  ZEN TEMPLE  🏯
       ▔▔▔▔▔▔▔▔▔▔
      
      Level 3 Cultivator
      ✨✨✨ (1240/1500 pts to level 4)
      
      🌸 Sakura Trees: 5
      🧘 Zen Temple: Unlocked
      🐟 Pet: Zen (Koi Fish)
      
      Decorations:
      🏮 Stone Lantern (7-day streak)
      🌉 Meditation Bridge (14-day)
      ⛲ Water Fountain (21-day)
      
      Your Streaks:
      🔥 Gym: 14 days
      🔥 Water: 21 days
      🔥 Reading: 8 days
      
      Next unlock: Golden Buddha @ 30-day habit streak
```

---

## Phase 5: Reminder System (Day 8-9)

### Multi-Layer Reminders Configuration

**For Habit: "Drink 8 glasses of water"**
Frequency: 8 times/day, 8 AM - 6 PM

**Layer 1: IMS Breaks (Instant Mindful Silence)**
```
Every 2 hours → Notification
  Sound: Tibetan singing bowl (3 sec)
  Message: "🌊 Time to hydrate. One glass centers you."
  Button: "Just logged!" | "Remind me later"
```

**Layer 2: Predictive Timing**
```
Smart detection:
  Pre-meeting (detected from Work IQ): 
    "Water + 1-min breath before your call?"
  
  Post-lunch (12:30 PM):
    "Hydration boost time 🌊"
  
  Afternoon slump (3 PM):
    "Drink, then take a 5-min walk?"
```

**Layer 3: Gamification**
```
Every 4 glasses logged: +5 Zen Points
7-day streak: "Hydration Hero" badge 🏆
Message: "You drank water 56/56 times this week. You're the master of flow."
```

**Layer 4: Contextual Nudge**
```
If not logged by 2 PM:
"You've been heads-down. Your body's asking for water.
 One glass centers you. 🌊"
```

### Notification Tone (Critical!)
```
❌ WRONG (Corporate, anxiety-inducing):
  "Complete water intake task"
  "Reminder: Hydration goal incomplete"

✅ RIGHT (Human, supportive):
  "One glass centers you. 🌊"
  "Your body's asking for water. Listen to it."
  "Hydration = focus. One glass?"
```

---

## Phase 6: Mental Health Support & Crisis Detection (Day 10)

### Trigger Phrases
```
- "i'm anxious"
- "i'm overwhelmed"
- "rough day"
- "everything feels too much"
- "i can't focus"
- "i'm burned out"
- "i want to disappear"
- "i can't do this anymore"
```

### Response Flow

**Step 1: Detect Crisis Level**
```
Low (Fatigue): Suggest 10-min walk
Medium (Anxiety/Stress): Suggest real action + IMS Breaks
High (Burnout): Suggest therapy/professional help
Critical: Recommend crisis line + human support
```

**Non-Crisis Response (Anxiety, Stress)**
```
"I see you. That feeling is real, and it matters.

🌍 ONE REAL ACTION (15 MIN):
1. Put your phone down
2. Step outside
3. Walk 10 min in a local park
4. Just breathe

When you come back, I'll be here. We'll reset together.
You're not broken. You're just human. 💚"
```

**Crisis Response (Suicidal, Self-Harm)**
```
"I see you. I'm here. But I need you to reach out to a human right now.

🆘 CRISIS RESOURCES:
• National Crisis Line: 988 (call or text)
• Text HOME to 741741
• International: findahelpline.com
• Go to your nearest ER if in immediate danger

You're not alone. Real humans care. Please reach out.
I'll be here when you need me. 💚"
```

---

## Phase 7: Bilingual Support (Day 11)

### Spanish Integration

**Detect Language:**
If user types in Spanish → Switch all responses to Spanish

**Key Translations:**
```
"You're not behind. You're just human."
→ "No estás atrasado. Solo eres humano."

"Let's reset — one spark at a time."
→ "Reiniciemos — una chispa a la vez."

"Zen Garden"
→ "Jardín Zen"

"Awaken your inner spark"
→ "Despierta tu chispa interior"
```

---

## Testing Checklist

- [ ] Sunday Planning flow: Voice note → organized week
- [ ] Habit logging: "Done with gym" → streak + points
- [ ] Missed habit: Compassionate response + reset
- [ ] Zen Garden: Shows ASCII + level + decorations
- [ ] Reminders: Tibetan bowl sound + gentle message
- [ ] Mental health: Crisis detection + human resources
- [ ] Bilingual: Spanish triggers → Spanish responses
- [ ] Points/Rewards: Habits → points → unlocks
- [ ] Database: All entities save correctly
- [ ] Integration: Foundry + Work IQ APIs functional

---

## Deployment to Production

```
Week 1: Core agent + Sunday Planning (pilot with 10 users)
Week 2: Add habit logging + rewards (expand to 50 users)
Week 3: Reminder system + IMS Breaks (100 users)
Week 4: Mental health support + bilingual (500 users)
Week 5: Zen Garden visualization + polish (public launch)
```

---

## Key Files

1. `chispai-copilot-setup.md` — Full configuration guide
2. `chispai-topics-config.json` — Topic/intent definitions
3. `QUICK-START-GUIDE.md` — This file

Deploy with confidence. Chispai awaits your inner spark. 🌿✨

---

**Questions?**
- Copilot Studio Docs: https://learn.microsoft.com/en-us/microsoft-cloud/dev/copilot/studio-copilots
- Azure Foundry: https://learn.microsoft.com/en-us/azure/ai-services/speech-service/
- Work IQ: https://support.microsoft.com/en-us/microsoft-copilot/microsoft-365-work-iq

**Built with Chispudo Philosophy: Awakening your spark, one micro-step at a time. 💚**
