#!/bin/bash

# Chispai Deployment Script
# Deploys infrastructure, database, and Azure Functions

set -e

echo "🚀 Starting Chispai Deployment..."

# ============================================
# CONFIGURATION
# ============================================
ENVIRONMENT=${1:-dev}
LOCATION=${2:-southeastasia}
RESOURCE_GROUP="chispai-${ENVIRONMENT}-rg"
PROJECT_NAME="chispai"

echo "📍 Environment: $ENVIRONMENT"
echo "📍 Location: $LOCATION"
echo "📍 Resource Group: $RESOURCE_GROUP"

# ============================================
# STEP 1: Create Resource Group
# ============================================
echo ""
echo "▶️  Creating Resource Group..."
az group create \
  --name $RESOURCE_GROUP \
  --location $LOCATION

# ============================================
# STEP 2: Deploy Infrastructure (Bicep)
# ============================================
echo ""
echo "▶️  Deploying Azure Infrastructure..."
az deployment group create \
  --resource-group $RESOURCE_GROUP \
  --template-file azure-infrastructure-setup.bicep \
  --parameters \
    environmentName=$ENVIRONMENT \
    projectName=$PROJECT_NAME \
    location=$LOCATION

# ============================================
# STEP 3: Get Resource Names
# ============================================
echo ""
echo "▶️  Retrieving resource information..."

SQL_SERVER=$(az deployment group show \
  --resource-group $RESOURCE_GROUP \
  --name azure-infrastructure-setup \
  --query properties.outputs.sqlServerName.value -o tsv)

SQL_DATABASE=$(az deployment group show \
  --resource-group $RESOURCE_GROUP \
  --name azure-infrastructure-setup \
  --query properties.outputs.sqlDatabaseName.value -o tsv)

COSMOS_ACCOUNT=$(az deployment group show \
  --resource-group $RESOURCE_GROUP \
  --name azure-infrastructure-setup \
  --query properties.outputs.cosmosAccountName.value -o tsv)

KEY_VAULT=$(az deployment group show \
  --resource-group $RESOURCE_GROUP \
  --name azure-infrastructure-setup \
  --query properties.outputs.keyVaultName.value -o tsv)

FUNCTION_APP=$(az deployment group show \
  --resource-group $RESOURCE_GROUP \
  --name azure-infrastructure-setup \
  --query properties.outputs.functionAppName.value -o tsv)

echo "✅ SQL Server: $SQL_SERVER"
echo "✅ SQL Database: $SQL_DATABASE"
echo "✅ Cosmos Account: $COSMOS_ACCOUNT"
echo "✅ Key Vault: $KEY_VAULT"
echo "✅ Function App: $FUNCTION_APP"

# ============================================
# STEP 4: Initialize SQL Database
# ============================================
echo ""
echo "▶️  Initializing SQL Database..."

# Get SQL credentials from Key Vault
SQL_ADMIN="chispai_admin"
SQL_PASSWORD=$(az keyvault secret show \
  --vault-name $KEY_VAULT \
  --name SqlAdminPassword \
  --query value -o tsv 2>/dev/null || echo "ChangeMe@12345!")

SQL_ENDPOINT="${SQL_SERVER}.database.windows.net"

echo "  SQL Endpoint: $SQL_ENDPOINT"

# Run SQL script (requires sqlcmd or Azure Data Studio)
sqlcmd -S $SQL_ENDPOINT -U $SQL_ADMIN -P "$SQL_PASSWORD" \
  -d $SQL_DATABASE -i database-init.sql

echo "✅ Database initialized"

# ============================================
# STEP 5: Deploy Azure Functions
# ============================================
echo ""
echo "▶️  Deploying Azure Functions..."

# Install dependencies
npm install

# Build and deploy
npm run build
npm run deploy

echo "✅ Azure Functions deployed"

# ============================================
# STEP 6: Configure Function App Settings
# ============================================
echo ""
echo "▶️  Configuring Function App..."

# Get connection strings
SQL_CONN_STRING=$(az keyvault secret show \
  --vault-name $KEY_VAULT \
  --name SqlConnectionString \
  --query value -o tsv)

COSMOS_CONN_STRING=$(az keyvault secret show \
  --vault-name $KEY_VAULT \
  --name CosmosConnectionString \
  --query value -o tsv)

# Set Function App configuration
az functionapp config appsettings set \
  --name $FUNCTION_APP \
  --resource-group $RESOURCE_GROUP \
  --settings \
    "SQL_CONNECTION_STRING=$SQL_CONN_STRING" \
    "COSMOS_CONNECTION_STRING=$COSMOS_CONN_STRING" \
    "ENVIRONMENT=$ENVIRONMENT" \
    "PROJECT_NAME=$PROJECT_NAME"

echo "✅ Function App configured"

# ============================================
# STEP 7: Deploy Copilot Studio Agent
# ============================================
echo ""
echo "▶️  Note: Copilot Studio Agent deployment is manual"
echo "  1. Go to https://copilotstudio.microsoft.com"
echo "  2. Import agent configuration from: chispai-topics-config.json"
echo "  3. Configure integrations:"
echo "     - Microsoft Foundry IQ (transcription)"
echo "     - Work IQ (calendar integration)"
echo "     - Azure Functions (reminders)"

# ============================================
# DEPLOYMENT SUMMARY
# ============================================
echo ""
echo "=================================================="
echo "✅ DEPLOYMENT COMPLETE"
echo "=================================================="
echo ""
echo "📦 Deployed Resources:"
echo "  • SQL Server: $SQL_SERVER"
echo "  • Cosmos DB: $COSMOS_ACCOUNT"
echo "  • Azure Functions: $FUNCTION_APP"
echo "  • Key Vault: $KEY_VAULT"
echo ""
echo "🔗 Next Steps:"
echo "  1. Verify Copilot Studio agent in Portal"
echo "  2. Test reminders: curl https://$FUNCTION_APP.azurewebsites.net/api/reminder-test"
echo "  3. Monitor: https://portal.azure.com/"
echo ""
echo "📊 Monitoring:"
echo "  • Application Insights: $RESOURCE_GROUP"
echo "  • Function Logs: https://portal.azure.com/#resource/subscriptions/..."
echo ""
echo "Built with Chispudo Philosophy: Awakening your spark, one micro-step at a time. 🌿✨"
