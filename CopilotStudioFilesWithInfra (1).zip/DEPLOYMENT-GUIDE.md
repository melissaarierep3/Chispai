# Chispai Deployment Guide

Complete step-by-step guide to deploy Chispai to Azure production.

---

## Prerequisites

✅ Azure Subscription (with credits or billing enabled)  
✅ Azure CLI installed (`az --version`)  
✅ Node.js 18+ installed (`node --version`)  
✅ Git installed  
✅ Azure Functions Core Tools (`func --version`)  
✅ SQL Server Management Studio or `sqlcmd` utility  

---

## Phase 1: Pre-Deployment (Day 1)

### 1.1 Create Azure Subscription & Resource Group

```bash
# Login to Azure
az login

# Set default subscription
az account set --subscription "Your Subscription Name"

# Create resource group
az group create \
  --name chispai-dev-rg \
  --location southeastasia
```

### 1.2 Prepare Environment Variables

```bash
# Copy the template
cp .env.example .env

# Edit with your Azure credentials
nano .env

# Key values to fill in:
# - AZURE_SUBSCRIPTION_ID
# - AZURE_TENANT_ID
# - SQL credentials (generated after deployment)
# - Cosmos credentials (generated after deployment)
```

### 1.3 Set up Azure CLI Defaults

```bash
az configure

# Default resource group
az config set defaults.group=chispai-dev-rg
az config set defaults.location=southeastasia
```

---

## Phase 2: Infrastructure Deployment (Day 2-3)

### 2.1 Deploy Azure Infrastructure (Bicep)

```bash
# Validate Bicep template
az bicep build -f azure-infrastructure-setup.bicep

# Deploy infrastructure
az deployment group create \
  --resource-group chispai-dev-rg \
  --template-file azure-infrastructure-setup.bicep \
  --parameters \
    environmentName=dev \
    projectName=chispai \
    location=southeastasia
```

Expected resources created:
- ✅ SQL Server + Database
- ✅ Cosmos DB Account + Containers
- ✅ Storage Account
- ✅ Key Vault
- ✅ App Service Plan
- ✅ Azure Function App

### 2.2 Retrieve Deployment Outputs

```bash
# Get resource names from deployment
DEPLOYMENT_ID="azure-infrastructure-setup-$(date +%s)"

az deployment group show \
  --resource-group chispai-dev-rg \
  --name $DEPLOYMENT_ID \
  --query properties.outputs
```

**Copy these into your `.env` file:**
- sqlServerName
- sqlDatabaseName
- cosmosAccountName
- keyVaultName
- functionAppName
- cosmosEndpoint

### 2.3 Configure SQL Server Firewall

```bash
# Allow Azure Services
az sql server firewall-rule create \
  --resource-group chispai-dev-rg \
  --server chispai-dev-sqlserver \
  --name AllowAzureServices \
  --start-ip-address 0.0.0.0 \
  --end-ip-address 0.0.0.0

# Allow your local IP (for management)
YOUR_IP=$(curl -s https://api.ipify.org)

az sql server firewall-rule create \
  --resource-group chispai-dev-rg \
  --server chispai-dev-sqlserver \
  --name AllowMyIP \
  --start-ip-address $YOUR_IP \
  --end-ip-address $YOUR_IP
```

---

## Phase 3: Database Initialization (Day 4)

### 3.1 Connect to SQL Server

**Option A: Using sqlcmd**

```bash
# Update credentials in .env first
source .env

sqlcmd -S $SQL_SERVER -U $SQL_USERNAME -P "$SQL_PASSWORD" \
  -d $SQL_DATABASE
```

**Option B: Using Azure Data Studio**
1. Download Azure Data Studio
2. Create connection: `chispai-dev-sqlserver.database.windows.net`
3. Username: `chispai_admin`
4. Open and run `database-init.sql`

### 3.2 Run Database Initialization Script

```bash
# Via sqlcmd
sqlcmd -S $SQL_SERVER -U $SQL_USERNAME -P "$SQL_PASSWORD" \
  -d $SQL_DATABASE -i database-init.sql

# Expected output: "Chispai database initialized successfully!"
```

### 3.3 Verify Database Tables

```sql
-- Connect to database
SELECT TABLE_NAME FROM INFORMATION_SCHEMA.TABLES 
WHERE TABLE_SCHEMA = 'dbo';

-- Expected tables:
-- Users, Habits, HabitLogs, ZenGardens, SundayPlans, 
-- MentalHealthLogs, ReminderSettings
```

---

## Phase 4: Deploy Azure Functions (Day 5)

### 4.1 Prepare Functions Project

```bash
# Install dependencies
npm install

# Verify function project structure
func templates list
```

### 4.2 Deploy Functions

```bash
# Using deploy script (recommended)
bash deploy.sh dev southeastasia

# OR manual deployment
npm run build
func azure functionapp publish chispai-dev-functions
```

### 4.3 Verify Function Deployment

```bash
# Check function app status
az functionapp show \
  --resource-group chispai-dev-rg \
  --name chispai-dev-functions \
  --query state

# Test function
curl https://chispai-dev-functions.azurewebsites.net/api/reminder-test

# View logs
func azure functionapp logstream chispai-dev-functions
```

---

## Phase 5: Configure Integrations (Day 6)

### 5.1 Microsoft Foundry (Speech & Transcription)

```bash
# Create Foundry API Key
az cognitiveservices account create \
  --resource-group chispai-dev-rg \
  --name chispai-foundry \
  --kind TextAnalytics \
  --sku S0 \
  --location southeastasia

# Get API key
az cognitiveservices account keys list \
  --resource-group chispai-dev-rg \
  --name chispai-foundry \
  --query key1
```

Add to `.env`:
```
FOUNDRY_API_KEY=<your-key>
FOUNDRY_API_ENDPOINT=https://southeastasia.api.cognitive.microsoft.com/
```

### 5.2 Microsoft Graph (Work IQ / Calendar)

```bash
# Register Azure AD Application
az ad app create \
  --display-name "Chispai Work IQ" \
  --required-resource-accesses '{
    "resourceAppId": "00000002-0000-0000-c000-000000000000",
    "resourceAccess": [
      {
        "id": "570282fd-fa86-469f-85f0-fc0f8b6e7c4a",
        "type": "Scope"
      }
    ]
  }'

# Get credentials and add to .env
WORK_IQ_API_KEY=<your-app-credentials>
WORK_IQ_ENDPOINT=https://graph.microsoft.com/v1.0
```

### 5.3 Azure Notification Hubs

```bash
# Create Notification Hub Namespace
az notification-hub namespace create \
  --resource-group chispai-dev-rg \
  --name chispai-dev-namespace \
  --location southeastasia

# Create Hub
az notification-hub create \
  --resource-group chispai-dev-rg \
  --namespace-name chispai-dev-namespace \
  --name chispai-hub

# Get connection string
az notification-hub authorization-rule list-keys \
  --resource-group chispai-dev-rg \
  --namespace-name chispai-dev-namespace \
  --hub-name chispai-hub \
  --name DefaultFullSharedAccessSignature
```

Add to `.env`:
```
NOTIFICATION_HUB_NAMESPACE=chispai-dev-namespace
NOTIFICATION_HUB_ENDPOINT=<your-endpoint>
NOTIFICATION_HUB_KEY=<your-key>
```

---

## Phase 6: Deploy Copilot Studio Agent (Day 7)

### 6.1 Create Copilot Studio Agent

1. Go to https://copilotstudio.microsoft.com
2. Click "New" → "Agent"
3. Name: "Chispai"
4. Enable Web, Teams, Custom Channel

### 6.2 Configure Agent Personality

```
Settings → Agent Behavior → System Prompt

Paste from: chispai-copilot-setup.md (System Prompt section)
```

### 6.3 Import Topics

1. Go to Topics
2. For each topic in `chispai-topics-config.json`:
   - Click "New Topic"
   - Copy topic configuration
   - Set triggers and conversation flows
   - Save and test

**Topics to import:**
- Sunday Planning
- Log Habit
- Missed Habit
- Mental Health Support
- Zen Garden Status
- Cortisol Detox
- Reminder Setup

### 6.4 Configure Integrations

**Integrations → Connector**

Add these connections:
1. **Microsoft Foundry** (Speech)
   - Endpoint: `${FOUNDRY_API_ENDPOINT}`
   - Key: `${FOUNDRY_API_KEY}`

2. **Work IQ** (Calendar)
   - Endpoint: `https://graph.microsoft.com/v1.0`
   - Token: Azure AD OAuth token

3. **Azure Functions** (Reminders)
   - Endpoint: `${FUNCTION_APP_URL}`
   - Function Key: (get from Azure Portal)

### 6.5 Test Agent

```bash
# Test via Web Chat
curl -X POST https://<your-agent-endpoint>/chat \
  -H "Content-Type: application/json" \
  -d '{
    "userId": "test-user-123",
    "message": "organize my week"
  }'

# Expected: Agent responds with weekly plan
```

---

## Phase 7: Testing & Validation (Day 8)

### 7.1 Test Sunday Planning Flow

```bash
# 1. Send voice note
curl -X POST https://<agent-endpoint>/chat \
  -H "Content-Type: application/json" \
  -d '{
    "userId": "test-user",
    "message": "This week is crazy. Pitch Monday, meetings Wednesday, need to gym 3x.",
    "type": "text"
  }'

# Expected: Week organized with day-by-day breakdown
```

### 7.2 Test Habit Logging

```bash
# Log a completed habit
curl -X POST https://<agent-endpoint>/chat \
  -d '{
    "userId": "test-user",
    "message": "Done with gym"
  }'

# Expected: Streak counter, points awarded, celebration message
```

### 7.3 Test Reminders

```bash
# Trigger reminder manually
curl -X POST https://chispai-dev-functions.azurewebsites.net/api/reminder-trigger \
  -H "Content-Type: application/json" \
  -d '{
    "userId": "test-user",
    "habitId": "test-habit",
    "type": "ims_break"
  }'

# Check Azure Function logs
func azure functionapp logstream chispai-dev-functions
```

### 7.4 Monitor Deployment

```bash
# View Application Insights
az monitor app-insights component show \
  --resource-group chispai-dev-rg \
  --app chispai-dev-insights

# View Function App Metrics
az monitor metrics list-definitions \
  --resource-group chispai-dev-rg \
  --resource chispai-dev-functions \
  --resource-type "Microsoft.Web/sites"
```

---

## Phase 8: Production Deployment (Day 9-10)

### 8.1 Create Production Environment

```bash
# Deploy prod infrastructure
bash deploy.sh prod southeastasia

# Expected: New resource group `chispai-prod-rg`
```

### 8.2 Promote from Staging to Production

```bash
# Scale up Function App to Premium tier
az functionapp plan update \
  --resource-group chispai-prod-rg \
  --name chispai-prod-appplan \
  --sku P1v2

# Enable auto-scaling
az monitor autoscale create \
  --resource-group chispai-prod-rg \
  --resource-name chispai-prod-functions \
  --resource-type "Microsoft.Web/sites" \
  --min-count 1 \
  --max-count 5 \
  --count 2
```

### 8.3 Configure Monitoring & Alerts

```bash
# Create action group for alerts
az monitor action-group create \
  --resource-group chispai-prod-rg \
  --name chispai-alerts \
  --short-name chispai

# Add metric alert for high error rate
az monitor metrics alert create \
  --resource-group chispai-prod-rg \
  --name "High Error Rate Alert" \
  --resource chispai-prod-functions \
  --condition "avg Failed_Requests > 10" \
  --window-size 5m \
  --evaluation-frequency 1m \
  --action chispai-alerts
```

---

## Deployment Checklist

- [ ] Azure subscription created
- [ ] Resource groups created (dev + prod)
- [ ] Bicep infrastructure deployed
- [ ] SQL database initialized with tables
- [ ] Cosmos DB containers created
- [ ] Key Vault configured with secrets
- [ ] Azure Functions deployed and tested
- [ ] Microsoft Foundry integrated
- [ ] Work IQ integrated
- [ ] Notification Hubs configured
- [ ] Copilot Studio agent created
- [ ] All 7 topics imported and tested
- [ ] Mental health crisis detection working
- [ ] Reminders triggering correctly (all 4 layers)
- [ ] Bilingual support (EN + ES) tested
- [ ] Production environment scaled up
- [ ] Monitoring & alerts configured
- [ ] Documentation updated
- [ ] Security review completed

---

## Troubleshooting

### Function App Deployment Fails

```bash
# Check function logs
func azure functionapp logstream chispai-dev-functions

# Redeploy with verbose output
func azure functionapp publish chispai-dev-functions --verbose
```

### Database Connection Issues

```bash
# Test SQL connection
sqlcmd -S $SQL_SERVER -U $SQL_USERNAME -P "$SQL_PASSWORD" \
  -d $SQL_DATABASE -Q "SELECT @@VERSION"

# Check firewall rules
az sql server firewall-rule list \
  --resource-group chispai-dev-rg \
  --server chispai-dev-sqlserver
```

### Agent Not Responding

1. Check Copilot Studio portal for errors
2. Verify all integrations are connected
3. Test agent via Web Chat
4. Check Function App logs for errors

### Reminders Not Sending

1. Verify `ReminderSettings` table is populated
2. Check `NOTIFICATION_HUB_KEY` in Function App settings
3. Review Function App logs
4. Test notification manually: `curl https://<function-url>/api/reminder-test`

---

## Cost Estimation (Monthly)

| Service | Tier | Cost |
|---------|------|------|
| SQL Database | S0 | $15 |
| Cosmos DB | Serverless | $0-50 |
| Azure Functions | Consumption | $0-20 |
| Storage | Standard | $5-10 |
| Key Vault | Standard | $1 |
| Notification Hubs | Free | $0 |
| **Total** | | **$20-100/mo** |

(Upgrade tiers as usage grows)

---

## Post-Deployment

1. **Monitor**: Set up daily reviews of metrics
2. **Backup**: Configure SQL automated backups
3. **Scale**: Increase resources as user base grows
4. **Security**: Enable MFA, role-based access control
5. **Updates**: Plan quarterly infrastructure reviews

---

**Built with Chispudo Philosophy: Awakening your spark, one micro-step at a time. 🌿✨**
